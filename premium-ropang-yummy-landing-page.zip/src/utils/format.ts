const idr = new Intl.NumberFormat("id-ID", {
  style: "currency",
  currency: "IDR",
  maximumFractionDigits: 0,
});

/** Formats a value as Indonesian Rupiah, e.g. "Rp 59.000". */
export const formatIDR = (value: number) => idr.format(value);

/** Formats a plain number with locale separators, e.g. "3.250.000". */
export const formatNumber = (value: number) => value.toLocaleString("id-ID");

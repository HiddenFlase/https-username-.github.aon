import { useCallback, useEffect, useRef, useState } from "react";
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import SocialProof from "./components/SocialProof";
import Features from "./components/Features";
import ProductShowcase from "./components/ProductShowcase";
import Benefits from "./components/Benefits";
import Testimonials from "./components/Testimonials";
import Pricing from "./components/Pricing";
import FAQ from "./components/FAQ";
import CTA from "./components/CTA";
import Footer from "./components/Footer";
import StickyBuyBar from "./components/StickyBuyBar";
import Toast from "./components/Toast";
import { LanguageProvider, useLang } from "./i18n/LanguageContext";
import { fill } from "./i18n/copy";

function Page() {
  const { t } = useLang();
  const [bagCount, setBagCount] = useState(0);
  const [bump, setBump] = useState(0);
  const [toast, setToast] = useState<string | null>(null);
  const toastTimer = useRef<number | undefined>(undefined);

  const addToBag = useCallback(
    (qty: number, label: string) => {
      setBagCount((count) => count + qty);
      setBump((n) => n + 1);
      setToast(fill(t.ui.toast, { qty, label }));
      window.clearTimeout(toastTimer.current);
      toastTimer.current = window.setTimeout(() => setToast(null), 2600);
    },
    [t]
  );

  useEffect(() => () => window.clearTimeout(toastTimer.current), []);

  return (
    <div className="relative min-h-screen overflow-x-clip">
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[80] focus:rounded-full focus:bg-ink focus:px-4 focus:py-2 focus:text-cream"
      >
        {t.ui.skip}
      </a>
      <div aria-hidden="true" className="grain" />

      <Navbar bagCount={bagCount} bump={bump} />

      <main id="main">
        <Hero />
        <SocialProof />
        <Features />
        <ProductShowcase onAdd={addToBag} />
        <Benefits />
        <Testimonials />
        <Pricing onAdd={addToBag} />
        <FAQ />
        <CTA />
      </main>

      <Footer />
      <StickyBuyBar />
      <Toast message={toast} />
    </div>
  );
}

export default function App() {
  return (
    <LanguageProvider>
      <Page />
    </LanguageProvider>
  );
}

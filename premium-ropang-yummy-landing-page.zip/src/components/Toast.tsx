import { Check } from "lucide-react";
import { cn } from "@/utils/cn";

type Props = {
  message: string | null;
};

/** Confirmation toast announced to screen readers when items are added to the bag. */
export default function Toast({ message }: Props) {
  return (
    <div
      role="status"
      aria-live="polite"
      className={cn(
        "pointer-events-none fixed left-1/2 top-24 z-[70] w-[calc(100%-2rem)] max-w-sm -translate-x-1/2 transition-all duration-500",
        message ? "translate-y-0 opacity-100" : "-translate-y-4 opacity-0"
      )}
    >
      <div className="glass flex items-center gap-3 rounded-2xl p-4">
        <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-rose-deep to-gold text-white">
          <Check className="h-4 w-4" aria-hidden="true" />
        </span>
        <p className="text-sm font-medium text-ink">{message ?? ""}</p>
      </div>
    </div>
  );
}

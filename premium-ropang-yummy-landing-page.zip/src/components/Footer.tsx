import Logo from "./Logo";
import { useLang } from "@/i18n/LanguageContext";

export default function Footer() {
  const { t } = useLang();
  const f = t.footer;

  return (
    <footer className="relative overflow-hidden bg-ink pb-28 text-cream md:pb-0">
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -top-40 left-1/2 h-80 w-[50rem] -translate-x-1/2 rounded-full bg-rose-deep/20 blur-3xl"
      />

      <div className="relative mx-auto max-w-7xl px-4 pb-10 pt-20 sm:px-6">
        <div className="grid gap-12 sm:grid-cols-2 lg:grid-cols-[1.4fr_1fr_1fr_1fr]">
          <div className="sm:col-span-2 lg:col-span-1">
            <a href="#top" aria-label={f.backToTop} className="group inline-flex">
              <Logo textClassName="text-2xl text-cream" />
            </a>
            <p className="mt-5 max-w-xs text-sm leading-relaxed text-cream/65">{f.blurb}</p>
            <ul className="mt-6 flex flex-wrap gap-3">
              {f.socials.map((social) => (
                <li key={social}>
                  <a
                    href="#top"
                    aria-label={`Ropang Yummy · ${social}`}
                    className="inline-flex rounded-full border border-white/15 px-4 py-2 text-xs font-medium text-cream/80 transition duration-300 hover:-translate-y-0.5 hover:border-white/40 hover:bg-white/10 hover:text-white"
                  >
                    {social}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {f.columns.map((column) => (
            <nav key={column.title} aria-label={column.title}>
              <h3 className="text-sm font-semibold uppercase tracking-[0.16em] text-cream/50">{column.title}</h3>
              <ul className="mt-5 space-y-3">
                {column.links.map((link) => (
                  <li key={link.label}>
                    <a
                      href={link.href}
                      className="link-underline inline-block text-sm text-cream/80 transition-colors duration-300 hover:text-white"
                    >
                      {link.label}
                    </a>
                  </li>
                ))}
              </ul>
            </nav>
          ))}
        </div>

        <div className="mt-16 flex flex-col gap-4 border-t border-white/10 pt-8 text-xs text-cream/50 sm:flex-row sm:items-center sm:justify-between">
          <p>{f.copyright}</p>
          <p>{f.credits}</p>
        </div>
      </div>
    </footer>
  );
}

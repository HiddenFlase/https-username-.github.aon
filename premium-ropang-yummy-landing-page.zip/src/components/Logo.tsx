import { cn } from "@/utils/cn";

type Props = {
  className?: string;
  textClassName?: string;
};

/** Ropang Yummy wordmark: a gradient monogram beside the brand name. */
export default function Logo({ className, textClassName }: Props) {
  return (
    <span className={cn("inline-flex items-center gap-2.5", className)}>
      <span
        aria-hidden="true"
        className="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br from-rose via-rose-deep to-gold font-display text-lg font-semibold text-white shadow-lg shadow-rose-deep/30 transition duration-500 group-hover:rotate-12"
      >
        R
      </span>
      <span className={cn("font-display text-xl font-semibold tracking-tight", textClassName)}>
        Ropang <em className="font-medium italic text-rose-deep">Yummy</em>
      </span>
    </span>
  );
}

import { useState } from "react";
import { ChevronDown, MessageCircle } from "lucide-react";
import Reveal from "./Reveal";
import SectionHeading from "./SectionHeading";
import { useLang } from "@/i18n/LanguageContext";
import { cn } from "@/utils/cn";

export default function FAQ() {
  const { t } = useLang();
  const f = t.faq;
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <section id="faq" aria-labelledby="faq-title" className="relative py-20 sm:py-28">
      <div className="mx-auto grid max-w-7xl gap-12 px-4 sm:px-6 lg:grid-cols-[1fr_1.3fr] lg:gap-20">
        <div className="lg:sticky lg:top-32 lg:self-start">
          <SectionHeading
            align="left"
            id="faq-title"
            eyebrow={f.eyebrow}
            title={f.title}
            description={f.description}
          />
          <Reveal delay={200}>
            <div className="glass mt-10 flex items-start gap-4 rounded-[1.75rem] p-6">
              <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-rose-deep to-gold text-white">
                <MessageCircle className="h-5 w-5" aria-hidden="true" />
              </span>
              <div>
                <p className="font-semibold text-ink">{f.stillCurious}</p>
                <p className="mt-1 text-sm leading-relaxed text-ink-soft">{f.stillCuriousText}</p>
              </div>
            </div>
          </Reveal>
        </div>

        <div className="border-t border-ink/10">
          {f.items.map((item, i) => {
            const isOpen = openIndex === i;
            const panelId = `faq-panel-${i}`;
            const buttonId = `faq-button-${i}`;
            return (
              <Reveal key={item.q} delay={i * 60}>
                <div className="border-b border-ink/10">
                  <h3>
                    <button
                      id={buttonId}
                      type="button"
                      aria-expanded={isOpen}
                      aria-controls={panelId}
                      onClick={() => setOpenIndex(isOpen ? null : i)}
                      className="group flex w-full items-center justify-between gap-6 py-6 text-left"
                    >
                      <span className="font-display text-xl font-medium text-ink transition-colors duration-300 group-hover:text-rose-deep sm:text-2xl">
                        {item.q}
                      </span>
                      <span
                        aria-hidden="true"
                        className={cn(
                          "flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-ink/10 bg-white/70 text-ink transition-all duration-500",
                          isOpen && "rotate-180 border-transparent bg-ink text-cream"
                        )}
                      >
                        <ChevronDown className="h-4 w-4" />
                      </span>
                    </button>
                  </h3>
                  <div
                    id={panelId}
                    role="region"
                    aria-labelledby={buttonId}
                    inert={!isOpen}
                    className={cn(
                      "grid transition-[grid-template-rows] duration-500 ease-out",
                      isOpen ? "grid-rows-[1fr]" : "grid-rows-[0fr]"
                    )}
                  >
                    <div className="overflow-hidden">
                      <p className="pb-7 pr-12 leading-relaxed text-ink-soft">{item.a}</p>
                    </div>
                  </div>
                </div>
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}

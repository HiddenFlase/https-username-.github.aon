import { ArrowRight } from "lucide-react";
import Reveal from "./Reveal";
import SectionHeading from "./SectionHeading";
import { useLang } from "@/i18n/LanguageContext";

export default function Benefits() {
  const { t } = useLang();
  const b = t.benefits;

  return (
    <section id="benefits" aria-labelledby="benefits-title" className="relative py-20 sm:py-28">
      <div className="mx-auto grid max-w-7xl items-center gap-20 px-4 sm:px-6 lg:grid-cols-2 lg:gap-24">
        <Reveal variant="scale" className="relative mx-auto w-full max-w-md pb-8">
          <div className="relative aspect-[4/5] overflow-hidden rounded-[2.5rem] shadow-2xl shadow-plum/25">
            <img
              src="/images/lifestyle.jpg"
              alt={b.imageAlt}
              width={800}
              height={1000}
              loading="lazy"
              className="h-full w-full object-cover transition duration-[1.2s] hover:scale-105"
            />
            <div aria-hidden="true" className="absolute inset-0 bg-gradient-to-t from-plum/45 via-transparent to-transparent" />
          </div>
          <div className="glass absolute -bottom-2 left-4 right-4 rounded-3xl p-6 sm:-left-8 sm:right-auto sm:w-72">
            <p className="font-display text-xl italic text-ink">{b.quote}</p>
            <p className="mt-2 text-sm text-ink-soft">{b.quoteBy}</p>
          </div>
        </Reveal>

        <div>
          <SectionHeading align="left" id="benefits-title" eyebrow={b.eyebrow} title={b.title} />

          <ol className="mt-12 space-y-2">
            {b.items.map((item, i) => (
              <li key={item.title}>
                <Reveal delay={i * 100}>
                  <div className="group flex gap-6 border-t border-ink/10 py-7">
                    <span className="font-display text-3xl italic text-rose-deep/60 transition-colors duration-500 group-hover:text-gold">
                      0{i + 1}
                    </span>
                    <div>
                      <h3 className="font-display text-2xl font-medium text-ink">{item.title}</h3>
                      <p className="mt-2 leading-relaxed text-ink-soft">{item.text}</p>
                    </div>
                  </div>
                </Reveal>
              </li>
            ))}
          </ol>

          <Reveal delay={400}>
            <a href="#pricing" className="btn-primary group mt-10">
              {b.cta}
              <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" aria-hidden="true" />
            </a>
          </Reveal>
        </div>
      </div>
    </section>
  );
}

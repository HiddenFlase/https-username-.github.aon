import { useState, type MouseEvent } from "react";
import { ArrowRight, Flame, Star } from "lucide-react";
import { useLang } from "@/i18n/LanguageContext";
import { fill } from "@/i18n/copy";

const avatars = [
  { initials: "SW", from: "#eab0bc", to: "#c4536d" },
  { initials: "DA", from: "#f3d9a4", to: "#d9a441" },
  { initials: "RK", from: "#c9d8bd", to: "#7d9b6a" },
  { initials: "AP", from: "#e3b9a8", to: "#7a4a3a" },
];

export default function Hero() {
  const { t } = useLang();
  const h = t.hero;
  const [tilt, setTilt] = useState({ x: 0, y: 0 });

  const handleMove = (e: MouseEvent<HTMLElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    setTilt({
      x: (e.clientX - rect.left) / rect.width - 0.5,
      y: (e.clientY - rect.top) / rect.height - 0.5,
    });
  };

  return (
    <section
      id="top"
      aria-labelledby="hero-title"
      onMouseMove={handleMove}
      onMouseLeave={() => setTilt({ x: 0, y: 0 })}
      className="relative isolate overflow-hidden pt-32 pb-20 sm:pt-36 lg:pt-40 lg:pb-28"
    >
      {/* Ambient background motion */}
      <div aria-hidden="true" className="pointer-events-none absolute inset-0 -z-10">
        <div className="absolute -left-24 -top-24 h-[30rem] w-[30rem] rounded-full bg-rose/60 blur-3xl animate-float-slow" />
        <div className="absolute -right-40 top-32 h-[34rem] w-[34rem] rounded-full bg-gold/25 blur-3xl animate-float-fast" />
        <div className="absolute -bottom-24 left-1/3 h-80 w-80 rounded-full bg-cocoa/15 blur-3xl animate-float-slow" />
      </div>

      <div className="mx-auto grid max-w-7xl items-center gap-16 px-4 sm:px-6 lg:grid-cols-12 lg:gap-10">
        <div className="text-center lg:col-span-6 lg:text-left">
          <div className="animate-rise" style={{ animationDelay: "0ms" }}>
            <span className="glass inline-flex items-center gap-2.5 rounded-full px-4 py-2 text-xs font-semibold tracking-wide text-ink-soft">
              <span className="relative flex h-2 w-2" aria-hidden="true">
                <span className="absolute inset-0 rounded-full bg-rose-deep animate-ping-soft" />
                <span className="relative h-2 w-2 rounded-full bg-rose-deep" />
              </span>
              {h.badge}
            </span>
          </div>

          <h1
            id="hero-title"
            className="mt-7 font-display text-[2.9rem] font-medium leading-[1.02] tracking-tight text-ink text-balance sm:text-6xl lg:text-[4.6rem]"
          >
            <span className="block animate-rise" style={{ animationDelay: "120ms" }}>
              {h.titleLead}
            </span>
            <span className="block animate-rise" style={{ animationDelay: "240ms" }}>
              {h.titleLine2} <em className="text-gradient italic">{h.accent}</em>
            </span>
          </h1>

          <p
            className="mx-auto mt-6 max-w-xl animate-rise text-base leading-relaxed text-ink-soft sm:text-lg lg:mx-0"
            style={{ animationDelay: "380ms" }}
          >
            {h.description}
          </p>

          <div
            className="mt-9 flex animate-rise flex-col items-center gap-3 sm:flex-row sm:justify-center lg:justify-start"
            style={{ animationDelay: "500ms" }}
          >
            <a href="#flavors" className="btn-primary group w-full sm:w-auto">
              {h.primaryCta}
              <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" aria-hidden="true" />
            </a>
            <a href="#benefits" className="btn-ghost w-full sm:w-auto">
              {h.secondaryCta}
            </a>
          </div>
          <p className="mt-4 animate-rise text-xs font-medium text-ink-soft" style={{ animationDelay: "600ms" }}>
            {h.startingPrice} · {h.freeDelivery}
          </p>

          <div
            className="mt-10 flex animate-rise flex-col items-center gap-4 sm:flex-row lg:justify-start"
            style={{ animationDelay: "700ms" }}
          >
            <div className="flex -space-x-3">
              {avatars.map((a) => (
                <span
                  key={a.initials}
                  className="flex h-11 w-11 items-center justify-center rounded-full border-2 border-cream text-xs font-semibold text-white shadow-md"
                  style={{ backgroundImage: `linear-gradient(135deg, ${a.from}, ${a.to})` }}
                  aria-hidden="true"
                >
                  {a.initials}
                </span>
              ))}
            </div>
            <div className="text-center sm:text-left">
              <div
                className="flex items-center justify-center gap-0.5 lg:justify-start"
                role="img"
                aria-label={fill(h.ratedLabel, { rating: h.rating })}
              >
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} className="h-4 w-4 fill-gold text-gold" aria-hidden="true" />
                ))}
                <span className="ml-2 text-sm font-semibold text-ink">{h.rating}</span>
              </div>
              <p className="text-sm text-ink-soft">{fill(h.lovedBy, { count: h.reviewCount })}</p>
            </div>
          </div>
        </div>

        <div className="relative mx-auto w-full max-w-md lg:col-span-6 lg:max-w-none">
          <div
            className="relative transition-transform duration-700 ease-out"
            style={{ transform: `translate3d(${tilt.x * 18}px, ${tilt.y * 14}px, 0)` }}
          >
            <div
              aria-hidden="true"
              className="absolute -inset-8 rounded-full border border-dashed border-rose-deep/20 animate-spin-slow"
            />
            <div
              className="relative aspect-[4/5] animate-rise overflow-hidden rounded-t-[12rem] rounded-b-[2.5rem] shadow-2xl shadow-plum/30"
              style={{ animationDelay: "200ms" }}
            >
              <img
                src="/images/hero.jpg"
                alt={h.imageAlt}
                width={800}
                height={1000}
                fetchPriority="high"
                className="h-full w-full object-cover"
              />
              <div aria-hidden="true" className="absolute inset-0 bg-gradient-to-t from-plum/35 via-transparent to-transparent" />
            </div>

            <div className="glass absolute -left-4 top-14 hidden animate-float-fast items-center gap-3 rounded-2xl p-3.5 pr-5 sm:flex lg:-left-10">
              <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-gold to-rose-deep text-white">
                <Flame className="h-5 w-5" aria-hidden="true" />
              </span>
              <div>
                <p className="text-sm font-semibold text-ink">{h.freshly}</p>
                <p className="text-xs text-ink-soft">{h.baked}</p>
              </div>
            </div>

            <div className="glass absolute -right-2 bottom-10 flex animate-float-slow items-center gap-3 rounded-2xl p-3.5 pr-5 sm:-right-6 lg:-right-8">
              <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-rose to-rose-deep text-white">
                <Star className="h-5 w-5 fill-white" aria-hidden="true" />
              </span>
              <div>
                <p className="text-sm font-semibold text-ink">{h.favorite}</p>
                <p className="text-xs text-ink-soft">{h.favoriteName}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

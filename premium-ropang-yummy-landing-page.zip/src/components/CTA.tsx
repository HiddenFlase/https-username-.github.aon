import { useEffect, useState, type FormEvent } from "react";
import { ArrowRight, Check, Mail } from "lucide-react";
import Reveal from "./Reveal";
import RichText from "./RichText";
import { useLang } from "@/i18n/LanguageContext";
import { cn } from "@/utils/cn";

function useCountdown(target: number) {
  const [now, setNow] = useState(() => Date.now());

  useEffect(() => {
    const id = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(id);
  }, []);

  const diff = Math.max(0, target - now);
  return {
    days: Math.floor(diff / 86_400_000),
    hours: Math.floor(diff / 3_600_000) % 24,
    minutes: Math.floor(diff / 60_000) % 60,
    seconds: Math.floor(diff / 1000) % 60,
  };
}

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export default function CTA() {
  const { t } = useLang();
  const c = t.cta;
  const [deadline] = useState(() => Date.now() + ((2 * 24 + 14) * 3600 + 9 * 60) * 1000);
  const time = useCountdown(deadline);
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState<"idle" | "error" | "success">("idle");

  const handleSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setStatus(EMAIL_PATTERN.test(email.trim()) ? "success" : "error");
  };

  const units = [
    { value: time.days, label: c.units.days },
    { value: time.hours, label: c.units.hours },
    { value: time.minutes, label: c.units.min },
    { value: time.seconds, label: c.units.sec },
  ];

  return (
    <section id="join" aria-labelledby="cta-title" className="relative px-4 py-20 sm:px-6 sm:py-28">
      <Reveal className="relative mx-auto max-w-7xl overflow-hidden rounded-[2.5rem] bg-gradient-to-br from-plum via-rose-deep to-cocoa px-6 py-16 text-cream shadow-2xl shadow-plum/30 sm:px-14 sm:py-24">
        <div
          aria-hidden="true"
          className="pointer-events-none absolute -left-20 -top-20 h-80 w-80 rounded-full bg-gold/40 blur-3xl animate-float-slow"
        />
        <div
          aria-hidden="true"
          className="pointer-events-none absolute -bottom-24 right-0 h-96 w-96 rounded-full bg-rose/40 blur-3xl animate-float-fast"
        />
        <div
          aria-hidden="true"
          className="pointer-events-none absolute inset-0 opacity-[0.07] [background-image:radial-gradient(#fff_1px,transparent_1px)] [background-size:22px_22px]"
        />

        <div className="relative mx-auto max-w-3xl text-center">
          <span className="inline-flex rounded-full border border-white/25 bg-white/10 px-4 py-1.5 text-xs font-semibold uppercase tracking-[0.18em] backdrop-blur">
            {c.badge}
          </span>

          <h2
            id="cta-title"
            className="mt-7 font-display text-4xl font-medium leading-[1.05] tracking-tight text-balance sm:text-6xl"
          >
            <RichText text={c.title} className="italic text-gold" />
          </h2>

          <p className="mx-auto mt-6 max-w-xl text-base leading-relaxed text-cream/80 sm:text-lg">{c.body}</p>

          <div role="timer" aria-label={c.timerLabel} className="mt-10 flex justify-center gap-3 sm:gap-4">
            {units.map((u) => (
              <div
                key={u.label}
                className="min-w-[4.5rem] rounded-2xl border border-white/20 bg-white/10 px-3 py-3 backdrop-blur sm:min-w-[5.5rem]"
              >
                <p className="font-display text-3xl font-medium tabular-nums sm:text-4xl">
                  {String(u.value).padStart(2, "0")}
                </p>
                <p className="text-[11px] uppercase tracking-widest text-cream/70">{u.label}</p>
              </div>
            ))}
          </div>

          {status === "success" ? (
            <div
              role="status"
              className="mx-auto mt-10 inline-flex animate-rise items-center gap-3 rounded-full bg-white/15 px-6 py-4 text-left backdrop-blur"
            >
              <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-gold text-ink">
                <Check className="h-4 w-4" aria-hidden="true" />
              </span>
              <span className="text-sm sm:text-base">
                {c.successBefore} <strong className="font-semibold text-gold">{c.code}</strong>
                {c.successAfter}
              </span>
            </div>
          ) : (
            <form onSubmit={handleSubmit} noValidate className="mx-auto mt-10 flex max-w-xl flex-col gap-3 sm:flex-row">
              <label htmlFor="cta-email" className="sr-only">
                {c.emailLabel}
              </label>
              <div className="relative flex-1">
                <Mail
                  className="pointer-events-none absolute left-5 top-1/2 h-5 w-5 -translate-y-1/2 text-cream/70"
                  aria-hidden="true"
                />
                <input
                  id="cta-email"
                  type="email"
                  autoComplete="email"
                  value={email}
                  onChange={(e) => {
                    setEmail(e.target.value);
                    if (status === "error") setStatus("idle");
                  }}
                  placeholder={c.placeholder}
                  aria-invalid={status === "error"}
                  aria-describedby={status === "error" ? "cta-error" : undefined}
                  className={cn(
                    "h-14 w-full rounded-full border border-white/25 bg-white/10 pl-14 pr-5 text-cream placeholder:text-cream/60 outline-none backdrop-blur transition focus:border-white/70 focus:bg-white/20 focus:ring-4 focus:ring-white/20"
                  )}
                />
              </div>
              <button type="submit" className="btn-light sheen group h-14">
                {c.submit}
                <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" aria-hidden="true" />
              </button>
            </form>
          )}

          {status === "error" && (
            <p id="cta-error" className="mt-3 text-sm font-medium text-gold">
              {c.errorEmail}
            </p>
          )}
          <p className="mt-5 text-xs text-cream/60">{c.noSpam}</p>
        </div>
      </Reveal>
    </section>
  );
}

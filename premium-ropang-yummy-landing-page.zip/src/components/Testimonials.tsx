import { useRef } from "react";
import { BadgeCheck, ChevronLeft, ChevronRight, Quote, Star } from "lucide-react";
import Reveal from "./Reveal";
import SectionHeading from "./SectionHeading";
import { useLang } from "@/i18n/LanguageContext";
import { fill } from "@/i18n/copy";
import { cn } from "@/utils/cn";

const avatarGradients = [
  "from-rose to-rose-deep",
  "from-gold to-rose-deep",
  "from-matcha to-cocoa",
  "from-rose-deep to-plum",
  "from-gold to-matcha",
  "from-cocoa to-plum",
];

const RATING = 5;

const initialsOf = (name: string) =>
  name
    .split(" ")
    .map((w) => w[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();

export default function Testimonials() {
  const { t } = useLang();
  const r = t.reviews;
  const trackRef = useRef<HTMLDivElement>(null);

  const scrollByCard = (direction: 1 | -1) => {
    const track = trackRef.current;
    if (!track) return;
    const card = track.querySelector<HTMLElement>("[data-card]");
    const step = card ? card.offsetWidth + 20 : track.clientWidth;
    const atEnd = direction === 1 && track.scrollLeft + track.clientWidth >= track.scrollWidth - 4;
    track.scrollTo({
      left: atEnd ? 0 : track.scrollLeft + direction * step,
      behavior: "smooth",
    });
  };

  return (
    <section id="reviews" aria-labelledby="reviews-title" className="relative overflow-hidden py-20 sm:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="flex flex-col gap-8 md:flex-row md:items-end md:justify-between">
          <SectionHeading align="left" id="reviews-title" eyebrow={r.eyebrow} title={r.title} />
          <Reveal delay={200} className="flex items-center gap-3">
            <div className="mr-2 hidden text-right sm:block">
              <p className="font-display text-2xl text-ink">{r.rating}</p>
              <p className="text-xs text-ink-soft">{r.verified}</p>
            </div>
            <button
              type="button"
              aria-label={r.prev}
              onClick={() => scrollByCard(-1)}
              className="flex h-12 w-12 items-center justify-center rounded-full border border-ink/10 bg-white/70 text-ink transition duration-300 hover:-translate-x-0.5 hover:bg-white hover:shadow-lg active:scale-95"
            >
              <ChevronLeft className="h-5 w-5" aria-hidden="true" />
            </button>
            <button
              type="button"
              aria-label={r.next}
              onClick={() => scrollByCard(1)}
              className="flex h-12 w-12 items-center justify-center rounded-full bg-ink text-cream transition duration-300 hover:translate-x-0.5 hover:shadow-lg active:scale-95"
            >
              <ChevronRight className="h-5 w-5" aria-hidden="true" />
            </button>
          </Reveal>
        </div>
      </div>

      <div
        ref={trackRef}
        tabIndex={0}
        role="region"
        aria-label={r.region}
        className="mx-auto mt-14 flex max-w-7xl snap-x snap-mandatory gap-5 overflow-x-auto scroll-smooth px-4 pb-10 [scrollbar-width:none] sm:px-6 [&::-webkit-scrollbar]:hidden"
      >
        {r.list.map((item, i) => (
          <figure
            key={item.name}
            data-card
            className="glass group flex w-[82%] shrink-0 snap-start flex-col rounded-[2rem] p-7 transition duration-500 hover:-translate-y-1 hover:shadow-2xl sm:w-[24rem] sm:p-8"
          >
            <Quote className="h-8 w-8 text-rose transition-colors duration-500 group-hover:text-gold" aria-hidden="true" />
            <div className="mt-5 flex gap-0.5" role="img" aria-label={fill(r.stars, { n: RATING })}>
              {Array.from({ length: 5 }).map((_, s) => (
                <Star
                  key={s}
                  aria-hidden="true"
                  className={cn("h-4 w-4", s < RATING ? "fill-gold text-gold" : "text-ink/15")}
                />
              ))}
            </div>
            <blockquote className="mt-4 flex-1 font-display text-xl leading-snug text-ink">“{item.quote}”</blockquote>
            <figcaption className="mt-8 flex items-center gap-3 border-t border-ink/10 pt-6">
              <span
                aria-hidden="true"
                className={cn(
                  "flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-gradient-to-br text-xs font-semibold text-white",
                  avatarGradients[i % avatarGradients.length]
                )}
              >
                {initialsOf(item.name)}
              </span>
              <span className="min-w-0">
                <span className="block truncate text-sm font-semibold text-ink">{item.name}</span>
                <span className="block truncate text-xs text-ink-soft">
                  {item.role} · {item.city}
                </span>
              </span>
              <span className="ml-auto flex shrink-0 items-center gap-1 text-[11px] font-medium text-matcha">
                <BadgeCheck className="h-4 w-4" aria-hidden="true" />
                {r.verifiedBadge}
              </span>
            </figcaption>
          </figure>
        ))}
      </div>
    </section>
  );
}

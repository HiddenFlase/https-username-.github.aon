import { useState } from "react";
import { Check } from "lucide-react";
import Reveal from "./Reveal";
import SectionHeading from "./SectionHeading";
import { planOrder, planPrices } from "@/data/content";
import { useLang } from "@/i18n/LanguageContext";
import { formatIDR } from "@/utils/format";
import { cn } from "@/utils/cn";

type Props = {
  onAdd: (qty: number, label: string) => void;
};

type Billing = "once" | "subscribe";

export default function Pricing({ onAdd }: Props) {
  const { t } = useLang();
  const p = t.pricing;
  const [billing, setBilling] = useState<Billing>("subscribe");
  const isSubscribe = billing === "subscribe";

  return (
    <section id="pricing" aria-labelledby="pricing-title" className="relative py-20 sm:py-28">
      <div
        aria-hidden="true"
        className="absolute left-1/2 top-40 h-96 w-[60rem] max-w-none -translate-x-1/2 rounded-full bg-rose/30 blur-3xl"
      />

      <div className="relative mx-auto max-w-7xl px-4 sm:px-6">
        <SectionHeading id="pricing-title" eyebrow={p.eyebrow} title={p.title} description={p.description} />

        <Reveal className="mt-10 flex justify-center">
          <div role="group" aria-label={p.billing} className="glass relative grid grid-cols-2 rounded-full p-1.5">
            <span
              aria-hidden="true"
              className={cn(
                "absolute inset-y-1.5 left-1.5 w-[calc(50%-0.375rem)] rounded-full bg-ink shadow-lg transition-transform duration-500 ease-out",
                isSubscribe && "translate-x-full"
              )}
            />
            <button
              type="button"
              aria-pressed={!isSubscribe}
              onClick={() => setBilling("once")}
              className={cn(
                "relative z-10 rounded-full px-5 py-2.5 text-sm font-semibold transition-colors duration-300 sm:px-7",
                !isSubscribe ? "text-cream" : "text-ink-soft hover:text-ink"
              )}
            >
              {p.oneTime}
            </button>
            <button
              type="button"
              aria-pressed={isSubscribe}
              onClick={() => setBilling("subscribe")}
              className={cn(
                "relative z-10 flex items-center gap-2 rounded-full px-5 py-2.5 text-sm font-semibold transition-colors duration-300 sm:px-7",
                isSubscribe ? "text-cream" : "text-ink-soft hover:text-ink"
              )}
            >
              {p.subscribe}
              <span className="rounded-full bg-gold px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide text-ink">
                {p.off}
              </span>
            </button>
          </div>
        </Reveal>

        <div className="mt-12 grid items-stretch gap-6 md:grid-cols-3">
          {planOrder.map((planId, i) => {
            const plan = p.plans[planId];
            const prices = planPrices[planId];
            const featured = planId === "ritual";
            const price = isSubscribe && prices.subscribePrice ? prices.subscribePrice : prices.price;
            const showSavings = isSubscribe && prices.subscribePrice !== undefined;

            return (
              <Reveal key={planId} delay={i * 120} className={cn(featured && "md:-mt-4")}>
                <article
                  className={cn(
                    "relative h-full rounded-[2rem] p-[1.5px] transition-transform duration-500 hover:-translate-y-2",
                    featured ? "bg-gradient-to-b from-rose-deep via-gold to-plum shadow-2xl shadow-rose-deep/25" : "bg-transparent"
                  )}
                >
                  <div
                    className={cn(
                      "flex h-full flex-col rounded-[calc(2rem-1.5px)] p-8 sm:p-9",
                      featured ? "bg-white/90 backdrop-blur-xl" : "glass"
                    )}
                  >
                    {plan.badge && (
                      <span className="absolute -top-3.5 left-1/2 -translate-x-1/2 rounded-full bg-gradient-to-r from-rose-deep to-gold px-4 py-1.5 text-xs font-semibold text-white shadow-lg shadow-rose-deep/30">
                        {plan.badge}
                      </span>
                    )}

                    <h3 className="font-display text-3xl font-medium text-ink">{plan.name}</h3>
                    <p className="mt-2 min-h-[3rem] text-sm leading-relaxed text-ink-soft">{plan.description}</p>

                    <div className="mt-6 flex items-baseline gap-2">
                      <p
                        key={price}
                        className="animate-fade-in font-display text-4xl font-medium tracking-tight text-ink tabular-nums sm:text-[2.6rem]"
                      >
                        {formatIDR(price)}
                      </p>
                      {plan.cadence && <span className="text-sm text-ink-soft">{plan.cadence}</span>}
                    </div>
                    <div className="mt-1 h-5 text-sm">
                      {showSavings && (
                        <span className="animate-fade-in text-ink-soft">
                          <s className="tabular-nums">{formatIDR(prices.price)}</s>
                          <span className="ml-2 font-semibold text-matcha">{p.save}</span>
                        </span>
                      )}
                    </div>

                    <ul className="mt-8 flex-1 space-y-3.5">
                      {plan.features.map((feature) => (
                        <li key={feature} className="flex gap-3 text-sm text-ink">
                          <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-blush text-rose-deep">
                            <Check className="h-3 w-3" aria-hidden="true" />
                          </span>
                          {feature}
                        </li>
                      ))}
                    </ul>

                    <button
                      type="button"
                      onClick={() => onAdd(1, plan.name)}
                      className={cn("mt-9 w-full", featured ? "btn-primary sheen" : "btn-ghost")}
                    >
                      {plan.cta}
                    </button>
                  </div>
                </article>
              </Reveal>
            );
          })}
        </div>

        <p className="mt-10 text-center text-xs text-ink-soft">{p.footnote}</p>
      </div>
    </section>
  );
}

import type { Rich } from "@/i18n/copy";
import { cn } from "@/utils/cn";

type Props = {
  text: Rich;
  className?: string;
};

/** Renders a heading string with one gradient-highlighted word. */
export default function RichText({ text, className = "text-gradient italic" }: Props) {
  return (
    <>
      {text.pre}
      <em className={cn(className)}>{text.em}</em>
      {text.post}
    </>
  );
}

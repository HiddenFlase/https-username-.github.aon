import type { MouseEvent, ReactNode } from "react";
import { cn } from "@/utils/cn";

type Props = {
  children: ReactNode;
  className?: string;
};

/** Glass card with a soft light that follows the cursor. */
export default function SpotlightCard({ children, className }: Props) {
  const handleMove = (e: MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    e.currentTarget.style.setProperty("--mx", `${e.clientX - rect.left}px`);
    e.currentTarget.style.setProperty("--my", `${e.clientY - rect.top}px`);
  };

  return (
    <div
      onMouseMove={handleMove}
      className={cn(
        "glass group relative overflow-hidden rounded-[2rem] transition duration-500 hover:-translate-y-1 hover:shadow-[0_30px_70px_-25px_rgba(107,45,70,0.35)]",
        className
      )}
    >
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 opacity-0 transition-opacity duration-500 group-hover:opacity-100"
        style={{
          background:
            "radial-gradient(420px circle at var(--mx, 50%) var(--my, 50%), rgba(234, 176, 188, 0.35), transparent 60%)",
        }}
      />
      <div className="relative">{children}</div>
    </div>
  );
}

import { useEffect, useState } from "react";
import { BOX_PRICE } from "@/data/content";
import { useLang } from "@/i18n/LanguageContext";
import { formatIDR } from "@/utils/format";
import { cn } from "@/utils/cn";

/** Mobile-only floating buy bar that appears once the visitor has scrolled past the hero. */
export default function StickyBuyBar() {
  const { t } = useLang();
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const onScroll = () => setVisible(window.scrollY > 700);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <div
      inert={!visible}
      className={cn(
        "fixed inset-x-4 bottom-4 z-40 transition-all duration-500 md:hidden",
        visible ? "translate-y-0 opacity-100" : "translate-y-24 opacity-0"
      )}
    >
      <div className="glass flex items-center justify-between gap-3 rounded-full py-2.5 pl-5 pr-2.5">
        <div className="min-w-0">
          <p className="truncate text-xs text-ink-soft">{t.flavors.items.cocoa.name}</p>
          <p className="font-semibold tabular-nums text-ink">{formatIDR(BOX_PRICE)}</p>
        </div>
        <a href="#flavors" className="btn-primary px-6 py-3 text-sm">
          {t.sticky.addToBag}
        </a>
      </div>
    </div>
  );
}

import Reveal from "./Reveal";
import RichText from "./RichText";
import type { Rich } from "@/i18n/copy";
import { cn } from "@/utils/cn";

type Props = {
  eyebrow: string;
  title: Rich;
  description?: string;
  align?: "center" | "left";
  id?: string;
};

export default function SectionHeading({ eyebrow, title, description, align = "center", id }: Props) {
  return (
    <div className={cn("max-w-2xl", align === "center" ? "mx-auto text-center" : "text-left")}>
      <Reveal>
        <span className="inline-flex items-center gap-2 rounded-full border border-rose-deep/15 bg-white/60 px-3.5 py-1.5 text-xs font-semibold uppercase tracking-[0.18em] text-rose-deep backdrop-blur">
          <span className="h-1.5 w-1.5 rounded-full bg-rose-deep" aria-hidden="true" />
          {eyebrow}
        </span>
      </Reveal>
      <Reveal delay={80}>
        <h2
          id={id}
          className="mt-5 font-display text-4xl font-medium leading-[1.08] tracking-tight text-ink text-balance sm:text-5xl"
        >
          <RichText text={title} />
        </h2>
      </Reveal>
      {description && (
        <Reveal delay={160}>
          <p className="mt-5 text-base leading-relaxed text-ink-soft sm:text-lg">{description}</p>
        </Reveal>
      )}
    </div>
  );
}

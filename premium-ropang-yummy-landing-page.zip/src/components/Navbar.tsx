import { useEffect, useState } from "react";
import { Menu, ShoppingBag, X } from "lucide-react";
import Logo from "./Logo";
import LanguageToggle from "./LanguageToggle";
import { useLang } from "@/i18n/LanguageContext";
import { fill } from "@/i18n/copy";
import { cn } from "@/utils/cn";

type Props = {
  bagCount: number;
  bump: number;
};

export default function Navbar({ bagCount, bump }: Props) {
  const { t } = useLang();
  const [scrolled, setScrolled] = useState(false);
  const [progress, setProgress] = useState(0);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    let ticking = false;
    const update = () => {
      const y = window.scrollY;
      const max = document.documentElement.scrollHeight - window.innerHeight;
      setScrolled(y > 24);
      setProgress(max > 0 ? (y / max) * 100 : 0);
      ticking = false;
    };
    const onScroll = () => {
      if (!ticking) {
        ticking = true;
        requestAnimationFrame(update);
      }
    };
    update();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open]);

  return (
    <header className="fixed inset-x-0 top-0 z-50">
      <nav aria-label={t.ui.mainNav} className="mx-auto max-w-7xl px-3 pt-3 sm:px-6 sm:pt-5">
        <div
          className={cn(
            "group flex items-center justify-between gap-3 rounded-full px-3 py-2.5 transition-all duration-500 sm:gap-4 sm:px-5",
            scrolled ? "glass" : "bg-transparent"
          )}
        >
          <a href="#top" aria-label={t.ui.home} className="shrink-0">
            <Logo textClassName="text-lg sm:text-xl" />
          </a>

          <ul className="hidden items-center gap-8 lg:flex">
            {t.nav.links.map((link) => (
              <li key={link.href}>
                <a
                  href={link.href}
                  className="link-underline text-sm font-medium text-ink-soft transition-colors duration-300 hover:text-ink"
                >
                  {link.label}
                </a>
              </li>
            ))}
          </ul>

          <div className="flex items-center gap-2 sm:gap-3">
            <LanguageToggle />

            <a
              href="#flavors"
              aria-label={fill(t.ui.bagLabel, { count: bagCount })}
              className="relative flex h-11 w-11 items-center justify-center rounded-full bg-ink text-cream transition duration-300 hover:scale-105 active:scale-95"
            >
              <ShoppingBag className="h-[18px] w-[18px]" aria-hidden="true" />
              {bagCount > 0 && (
                <span
                  key={bump}
                  aria-hidden="true"
                  className="absolute -right-1 -top-1 flex h-5 min-w-5 animate-bump items-center justify-center rounded-full bg-gold px-1 text-[11px] font-bold text-ink"
                >
                  {bagCount}
                </span>
              )}
            </a>

            <a href="#pricing" className="btn-primary hidden px-5 py-2.5 lg:inline-flex">
              {t.ui.shopNow}
            </a>

            <button
              type="button"
              onClick={() => setOpen((v) => !v)}
              aria-expanded={open}
              aria-controls="mobile-menu"
              aria-label={open ? t.ui.closeMenu : t.ui.openMenu}
              className="flex h-11 w-11 items-center justify-center rounded-full border border-ink/10 bg-white/70 text-ink transition hover:bg-white lg:hidden"
            >
              {open ? <X className="h-5 w-5" aria-hidden="true" /> : <Menu className="h-5 w-5" aria-hidden="true" />}
            </button>
          </div>
        </div>

        <div
          id="mobile-menu"
          inert={!open}
          className={cn(
            "glass mt-2 overflow-hidden rounded-3xl transition-all duration-500 ease-out lg:hidden",
            open ? "max-h-96 opacity-100" : "max-h-0 border-transparent opacity-0 shadow-none"
          )}
        >
          <ul className="flex flex-col p-3">
            {t.nav.links.map((link) => (
              <li key={link.href}>
                <a
                  href={link.href}
                  onClick={() => setOpen(false)}
                  className="flex items-center justify-between rounded-2xl px-4 py-3.5 font-display text-xl text-ink transition hover:bg-blush/60"
                >
                  {link.label}
                </a>
              </li>
            ))}
            <li className="mt-2 px-1 pb-1">
              <a href="#pricing" onClick={() => setOpen(false)} className="btn-primary w-full">
                {t.ui.shopNow}
              </a>
            </li>
          </ul>
        </div>
      </nav>

      <div
        aria-hidden="true"
        className={cn(
          "absolute inset-x-0 bottom-0 h-[2px] transition-opacity duration-500",
          scrolled ? "opacity-100" : "opacity-0"
        )}
      >
        <div className="h-full bg-gradient-to-r from-rose-deep via-rose to-gold" style={{ width: `${progress}%` }} />
      </div>
    </header>
  );
}

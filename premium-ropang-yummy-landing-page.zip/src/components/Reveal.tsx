import type { CSSProperties, ReactNode } from "react";
import { useInView } from "@/hooks/useInView";
import { cn } from "@/utils/cn";

type Props = {
  children: ReactNode;
  /** Stagger delay in milliseconds. */
  delay?: number;
  variant?: "up" | "left" | "right" | "scale";
  className?: string;
};

/** Wraps content in a scroll-reveal container. */
export default function Reveal({ children, delay = 0, variant = "up", className }: Props) {
  const { ref, inView } = useInView<HTMLDivElement>();

  return (
    <div
      ref={ref}
      data-in={inView}
      data-variant={variant}
      className={cn("reveal", className)}
      style={{ "--delay": `${delay}ms` } as CSSProperties}
    >
      {children}
    </div>
  );
}

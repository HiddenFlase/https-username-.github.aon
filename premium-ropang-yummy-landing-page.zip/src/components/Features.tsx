import { Clock, Gift, Layers, Leaf, Sparkles, Truck } from "lucide-react";
import Reveal from "./Reveal";
import SectionHeading from "./SectionHeading";
import SpotlightCard from "./SpotlightCard";
import { useLang } from "@/i18n/LanguageContext";
import { cn } from "@/utils/cn";

const icons = [Sparkles, Leaf, Clock, Layers, Gift, Truck];

/** Indices of cards that span two columns on desktop, forming a balanced bento grid. */
const wideCards = new Set([0, 3, 5]);

export default function Features() {
  const { t } = useLang();
  const f = t.features;

  return (
    <section id="features" aria-labelledby="features-title" className="relative py-20 sm:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <SectionHeading id="features-title" eyebrow={f.eyebrow} title={f.title} description={f.description} />

        <div className="mt-16 grid gap-5 md:grid-cols-3">
          {f.items.map((item, i) => {
            const Icon = icons[i];
            return (
              <Reveal key={item.title} delay={(i % 3) * 110} className={cn(wideCards.has(i) && "md:col-span-2")}>
                <SpotlightCard className="h-full p-7 sm:p-9">
                  <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-blush to-white text-rose-deep shadow-inner transition duration-500 group-hover:-rotate-6 group-hover:scale-110">
                    <Icon className="h-6 w-6" aria-hidden="true" />
                  </span>
                  <h3 className="mt-6 font-display text-2xl font-medium text-ink">{item.title}</h3>
                  <p className="mt-3 max-w-md leading-relaxed text-ink-soft">{item.text}</p>
                </SpotlightCard>
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}

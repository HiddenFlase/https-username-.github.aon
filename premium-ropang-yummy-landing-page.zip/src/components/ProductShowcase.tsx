import { useEffect, useState, type MouseEvent } from "react";
import { Check, Clock, Minus, Plus, ShieldCheck, ShoppingBag, Truck } from "lucide-react";
import Reveal from "./Reveal";
import SectionHeading from "./SectionHeading";
import { BOX_PRICE, flavors } from "@/data/content";
import { useLang } from "@/i18n/LanguageContext";
import { fill } from "@/i18n/copy";
import { formatIDR } from "@/utils/format";
import { cn } from "@/utils/cn";

type Props = {
  onAdd: (qty: number, label: string) => void;
};

const perkIcons = [Truck, Clock, ShieldCheck];

export default function ProductShowcase({ onAdd }: Props) {
  const { t } = useLang();
  const p = t.flavors;
  const [index, setIndex] = useState(0);
  const [qty, setQty] = useState(1);
  const [added, setAdded] = useState(false);
  const [tilt, setTilt] = useState({ x: 0, y: 0 });

  const current = flavors[index];
  const copyItem = p.items[current.id];

  useEffect(() => {
    if (!added) return;
    const timer = window.setTimeout(() => setAdded(false), 1800);
    return () => window.clearTimeout(timer);
  }, [added]);

  const handleMove = (e: MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    setTilt({
      x: (e.clientX - rect.left) / rect.width - 0.5,
      y: (e.clientY - rect.top) / rect.height - 0.5,
    });
  };

  const handleAdd = () => {
    onAdd(qty, copyItem.name);
    setAdded(true);
  };

  return (
    <section id="flavors" aria-labelledby="flavors-title" className="relative overflow-hidden py-20 sm:py-28">
      <div
        aria-hidden="true"
        className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-rose-deep/30 to-transparent"
      />

      <div className="mx-auto grid max-w-7xl items-center gap-14 px-4 sm:px-6 lg:grid-cols-2 lg:gap-20">
        {/* Product visual */}
        <Reveal variant="left">
          <div
            onMouseMove={handleMove}
            onMouseLeave={() => setTilt({ x: 0, y: 0 })}
            className="relative mx-auto aspect-square w-full max-w-lg [perspective:1200px]"
          >
            <div
              aria-hidden="true"
              className="absolute inset-8 rounded-full opacity-35 blur-3xl transition-colors duration-700"
              style={{ backgroundColor: current.color }}
            />
            <div
              className="relative h-full w-full transition-transform duration-500 ease-out [transform-style:preserve-3d]"
              style={{ transform: `rotateX(${-tilt.y * 8}deg) rotateY(${tilt.x * 10}deg)` }}
            >
              <img
                src="/images/product.jpg"
                alt={fill(p.imageAlt, { name: copyItem.name })}
                width={900}
                height={900}
                loading="lazy"
                className="h-full w-full rounded-[2.5rem] object-cover shadow-2xl shadow-plum/30"
              />
            </div>

            <div
              key={current.id}
              className="glass absolute left-2 top-6 flex animate-rise items-center gap-2 rounded-full px-4 py-2 text-sm font-semibold text-ink sm:left-0"
            >
              <span className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: current.color }} aria-hidden="true" />
              {copyItem.badge}
            </div>

            <div className="glass absolute bottom-6 right-2 hidden animate-float-slow rounded-2xl px-5 py-4 sm:block">
              <p className="font-display text-lg text-ink">{p.sixSlices}</p>
              <p className="text-xs text-ink-soft">{p.ready}</p>
            </div>
          </div>
        </Reveal>

        {/* Purchase panel */}
        <div>
          <SectionHeading
            align="left"
            id="flavors-title"
            eyebrow={p.eyebrow}
            title={p.title}
            description={p.description}
          />

          <div role="group" aria-label={p.groupLabel} className="mt-10 grid grid-cols-2 gap-3 sm:grid-cols-4">
            {flavors.map((f, i) => {
              const active = i === index;
              const item = p.items[f.id];
              return (
                <Reveal key={f.id} delay={i * 70}>
                  <button
                    type="button"
                    aria-pressed={active}
                    onClick={() => setIndex(i)}
                    className={cn(
                      "group flex w-full flex-col items-start gap-3 rounded-2xl border p-4 text-left transition duration-300 hover:-translate-y-0.5",
                      active
                        ? "border-transparent bg-white shadow-xl shadow-plum/10 ring-2 ring-rose-deep/70"
                        : "border-ink/10 bg-white/50 hover:bg-white/80"
                    )}
                  >
                    <span
                      aria-hidden="true"
                      className="h-8 w-8 rounded-full shadow-inner transition-transform duration-500 group-hover:scale-110"
                      style={{ background: `radial-gradient(circle at 30% 30%, #ffffffaa, ${f.color})` }}
                    />
                    <span className="text-sm font-semibold leading-snug text-ink">{item.short}</span>
                  </button>
                </Reveal>
              );
            })}
          </div>

          <div key={current.id} className="mt-10 animate-rise">
            <h3 className="font-display text-3xl font-medium text-ink sm:text-4xl">{copyItem.name}</h3>
            <p className="mt-3 leading-relaxed text-ink-soft">{copyItem.description}</p>
            <ul className="mt-5 flex flex-wrap gap-2">
              {copyItem.notes.map((note) => (
                <li key={note} className="rounded-full bg-blush/70 px-3 py-1 text-xs font-medium text-plum">
                  {note}
                </li>
              ))}
            </ul>
          </div>

          <div className="glass mt-10 flex flex-col gap-5 rounded-[2rem] p-5 sm:p-6">
            <p className="font-display text-2xl text-ink tabular-nums">
              {formatIDR(BOX_PRICE)} <span className="font-sans text-sm text-ink-soft">{p.perBox}</span>
            </p>

            <div className="flex flex-col gap-4 sm:flex-row sm:items-center">
              <div className="flex w-fit items-center rounded-full border border-ink/10 bg-white/80 p-1">
                <button
                  type="button"
                  aria-label={p.decrease}
                  onClick={() => setQty((q) => Math.max(1, q - 1))}
                  className="flex h-10 w-10 items-center justify-center rounded-full text-ink transition hover:bg-blush active:scale-90"
                >
                  <Minus className="h-4 w-4" aria-hidden="true" />
                </button>
                <span className="w-10 text-center font-semibold tabular-nums" aria-live="polite">
                  {qty}
                </span>
                <button
                  type="button"
                  aria-label={p.increase}
                  onClick={() => setQty((q) => Math.min(6, q + 1))}
                  className="flex h-10 w-10 items-center justify-center rounded-full text-ink transition hover:bg-blush active:scale-90"
                >
                  <Plus className="h-4 w-4" aria-hidden="true" />
                </button>
              </div>

              <button type="button" onClick={handleAdd} className="btn-primary sheen flex-1">
                {added ? (
                  <>
                    <Check className="h-4 w-4" aria-hidden="true" />
                    {p.added}
                  </>
                ) : (
                  <>
                    <ShoppingBag className="h-4 w-4" aria-hidden="true" />
                    {fill(p.addToBag, { price: formatIDR(BOX_PRICE * qty) })}
                  </>
                )}
              </button>
            </div>
          </div>

          <ul className="mt-6 grid gap-3 text-sm text-ink-soft sm:grid-cols-3">
            {p.perks.map((perk, i) => {
              const Icon = perkIcons[i];
              return (
                <li key={perk} className="flex items-center gap-2">
                  <Icon className="h-4 w-4 shrink-0 text-rose-deep" aria-hidden="true" />
                  {perk}
                </li>
              );
            })}
          </ul>
        </div>
      </div>
    </section>
  );
}

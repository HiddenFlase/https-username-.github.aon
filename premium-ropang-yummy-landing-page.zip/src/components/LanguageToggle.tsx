import { useLang } from "@/i18n/LanguageContext";
import type { Lang } from "@/i18n/copy";
import { cn } from "@/utils/cn";

const options: { code: Lang; short: string; full: string }[] = [
  { code: "id", short: "ID", full: "Bahasa Indonesia" },
  { code: "en", short: "EN", full: "English" },
];

/** Segmented ID / EN switch with a sliding indicator. */
export default function LanguageToggle({ className }: { className?: string }) {
  const { lang, setLang, t } = useLang();

  return (
    <div
      role="group"
      aria-label={t.ui.languageGroup}
      className={cn("glass relative grid w-20 grid-cols-2 rounded-full p-1", className)}
    >
      <span
        aria-hidden="true"
        className={cn(
          "absolute inset-y-1 left-1 w-[calc(50%-0.25rem)] rounded-full bg-ink shadow-md transition-transform duration-500 ease-out",
          lang === "en" && "translate-x-full"
        )}
      />
      {options.map((opt) => {
        const active = lang === opt.code;
        return (
          <button
            key={opt.code}
            type="button"
            aria-pressed={active}
            aria-label={opt.full}
            title={opt.full}
            onClick={() => setLang(opt.code)}
            className={cn(
              "relative z-10 rounded-full py-1.5 text-[11px] font-bold tracking-wider transition-colors duration-300",
              active ? "text-cream" : "text-ink-soft hover:text-ink"
            )}
          >
            {opt.short}
          </button>
        );
      })}
    </div>
  );
}

import { Sparkles } from "lucide-react";
import CountUp from "./CountUp";
import Reveal from "./Reveal";
import RichText from "./RichText";
import { goal, statNumbers } from "@/data/content";
import { useLang } from "@/i18n/LanguageContext";
import { fill } from "@/i18n/copy";
import { useInView } from "@/hooks/useInView";
import { formatNumber } from "@/utils/format";

export default function SocialProof() {
  const { t } = useLang();
  const s = t.social;
  const percent = Math.round((goal.current / goal.target) * 100);
  const { ref: goalRef, inView: goalInView } = useInView<HTMLDivElement>();

  return (
    <section aria-label={s.ariaLabel} className="relative py-16 sm:py-20">
      {/* Infinite marquee */}
      <div className="group overflow-hidden border-y border-ink/5 bg-white/40 py-5 backdrop-blur-sm">
        <div className="flex w-max animate-marquee group-hover:[animation-play-state:paused]">
          {[0, 1].map((copy) => (
            <ul key={copy} aria-hidden={copy === 1} className="flex shrink-0 items-center gap-10 pr-10">
              {t.marquee.map((item) => (
                <li
                  key={`${copy}-${item}`}
                  className="flex items-center gap-10 whitespace-nowrap font-display text-xl italic text-ink-soft sm:text-2xl"
                >
                  {item}
                  <Sparkles className="h-4 w-4 text-rose-deep" aria-hidden="true" />
                </li>
              ))}
            </ul>
          ))}
        </div>
      </div>

      {/* Stats */}
      <div className="mx-auto mt-14 grid max-w-7xl grid-cols-2 gap-4 px-4 sm:px-6 lg:grid-cols-4 lg:gap-6">
        {s.stats.map((stat, i) => (
          <Reveal key={stat.label} delay={i * 90}>
            <div className="glass h-full rounded-[1.75rem] p-6 transition duration-500 hover:-translate-y-1 hover:shadow-2xl sm:p-8">
              <p className="font-display text-4xl font-medium tracking-tight text-ink tabular-nums sm:text-5xl">
                <CountUp to={statNumbers[i].to} decimals={statNumbers[i].decimals} suffix={stat.suffix} />
              </p>
              <p className="mt-2 text-sm text-ink-soft">{stat.label}</p>
            </div>
          </Reveal>
        ))}
      </div>

      {/* Sales goal */}
      <Reveal className="mx-auto mt-6 max-w-7xl px-4 sm:px-6">
        <div ref={goalRef} className="glass relative overflow-hidden rounded-[2rem] p-7 sm:p-10">
          <div
            aria-hidden="true"
            className="absolute -right-16 -top-16 h-56 w-56 rounded-full bg-gold/30 blur-3xl animate-float-slow"
          />
          <div className="relative grid gap-8 md:grid-cols-[1fr_1.2fr] md:items-end">
            <div>
              <p className="text-xs font-semibold uppercase tracking-[0.18em] text-rose-deep">{s.goalEyebrow}</p>
              <p className="mt-3 font-display text-3xl font-medium leading-tight text-ink sm:text-4xl">
                <RichText text={s.goalTitle} />
              </p>
              <p className="mt-3 text-sm leading-relaxed text-ink-soft">{s.goalBody}</p>
            </div>
            <div>
              <div className="flex items-end justify-between text-sm">
                <span className="font-semibold text-ink tabular-nums">
                  {fill(s.sold, { n: formatNumber(goal.current) })}
                </span>
                <span className="text-ink-soft tabular-nums">{fill(s.goalLabel, { n: formatNumber(goal.target) })}</span>
              </div>
              <div
                role="progressbar"
                aria-label={s.progressLabel}
                aria-valuemin={0}
                aria-valuemax={goal.target}
                aria-valuenow={goal.current}
                className="mt-3 h-3.5 w-full overflow-hidden rounded-full bg-blush"
              >
                <div
                  className="h-full rounded-full bg-gradient-to-r from-rose-deep via-rose to-gold transition-[width] duration-[1600ms] ease-out"
                  style={{ width: goalInView ? `${percent}%` : "0%" }}
                />
              </div>
              <p className="mt-3 text-right text-sm font-semibold text-rose-deep">{fill(s.percent, { p: percent })}</p>
            </div>
          </div>
        </div>
      </Reveal>
    </section>
  );
}

export type Lang = "id" | "en";
export type PlanId = "taste" | "ritual" | "sisterhood";
export type FlavorId = "cocoa" | "strawberry" | "matcha" | "garlic";

/** Heading with one gradient-highlighted word, e.g. "Small details, *big* indulgence." */
export type Rich = { pre: string; em: string; post: string };

type Item = { title: string; text: string };
type QA = { q: string; a: string };
type Review = { name: string; role: string; city: string; quote: string };
type FlavorCopy = { name: string; short: string; badge: string; notes: string[]; description: string };
type PlanCopy = { name: string; description: string; cta: string; features: string[]; cadence?: string; badge?: string };

export type Copy = {
  meta: { title: string; description: string; htmlLang: string };
  ui: {
    skip: string;
    home: string;
    openMenu: string;
    closeMenu: string;
    bagLabel: string;
    mainNav: string;
    shopNow: string;
    languageGroup: string;
    toast: string;
  };
  nav: { links: { label: string; href: string }[] };
  hero: {
    badge: string;
    titleLead: string;
    titleLine2: string;
    accent: string;
    description: string;
    primaryCta: string;
    secondaryCta: string;
    startingPrice: string;
    freeDelivery: string;
    ratedLabel: string;
    lovedBy: string;
    rating: string;
    reviewCount: string;
    imageAlt: string;
    freshly: string;
    baked: string;
    favorite: string;
    favoriteName: string;
  };
  marquee: string[];
  social: {
    ariaLabel: string;
    stats: { suffix: string; label: string }[];
    goalEyebrow: string;
    goalTitle: Rich;
    goalBody: string;
    sold: string;
    goalLabel: string;
    percent: string;
    progressLabel: string;
  };
  features: { eyebrow: string; title: Rich; description: string; items: Item[] };
  flavors: {
    eyebrow: string;
    title: Rich;
    description: string;
    groupLabel: string;
    perBox: string;
    sixSlices: string;
    ready: string;
    addToBag: string;
    added: string;
    decrease: string;
    increase: string;
    perks: string[];
    imageAlt: string;
    items: Record<FlavorId, FlavorCopy>;
  };
  benefits: { eyebrow: string; title: Rich; quote: string; quoteBy: string; cta: string; imageAlt: string; items: Item[] };
  reviews: {
    eyebrow: string;
    title: Rich;
    rating: string;
    verified: string;
    prev: string;
    next: string;
    region: string;
    verifiedBadge: string;
    stars: string;
    list: Review[];
  };
  pricing: {
    eyebrow: string;
    title: Rich;
    description: string;
    billing: string;
    oneTime: string;
    subscribe: string;
    off: string;
    save: string;
    footnote: string;
    plans: Record<PlanId, PlanCopy>;
  };
  faq: { eyebrow: string; title: Rich; description: string; stillCurious: string; stillCuriousText: string; items: QA[] };
  cta: {
    badge: string;
    title: Rich;
    body: string;
    timerLabel: string;
    units: { days: string; hours: string; min: string; sec: string };
    emailLabel: string;
    placeholder: string;
    submit: string;
    successBefore: string;
    successAfter: string;
    code: string;
    errorEmail: string;
    noSpam: string;
  };
  footer: {
    blurb: string;
    socials: string[];
    backToTop: string;
    columns: { title: string; links: { label: string; href: string }[] }[];
    copyright: string;
    credits: string;
  };
  sticky: { addToBag: string };
};

/** Replaces {placeholders} in a template string. */
export const fill = (template: string, vars: Record<string, string | number>) =>
  template.replace(/\{(\w+)\}/g, (_, key: string) => String(vars[key] ?? ""));

const en: Copy = {
  meta: {
    title: "Ropang Yummy | Toast That Feels Like Self-Care",
    description:
      "Ropang Yummy: slow-toasted ropang layered with indulgent spreads, made for the women who deserve something delicious every day.",
    htmlLang: "en",
  },
  ui: {
    skip: "Skip to content",
    home: "Ropang Yummy, back to top",
    openMenu: "Open menu",
    closeMenu: "Close menu",
    bagLabel: "Shopping bag, {count} items",
    mainNav: "Main navigation",
    shopNow: "Shop now",
    languageGroup: "Language",
    toast: "Added {qty} × {label} to your bag",
  },
  nav: {
    links: [
      { label: "Flavors", href: "#flavors" },
      { label: "Why Ropang", href: "#benefits" },
      { label: "Reviews", href: "#reviews" },
      { label: "Pricing", href: "#pricing" },
      { label: "FAQ", href: "#faq" },
    ],
  },
  hero: {
    badge: "New · Slow-toasted to order",
    titleLead: "Toast that",
    titleLine2: "feels like",
    accent: "self-care.",
    description:
      "Ropang Yummy is slow-toasted bread, golden and crisp, layered with indulgent spreads. A three-minute ritual designed for the woman who gives her day to everyone else and deserves something exquisite.",
    primaryCta: "Shop your first box",
    secondaryCta: "Why Ropang",
    startingPrice: "From Rp 59.000",
    freeDelivery: "Free delivery over Rp 150.000",
    ratedLabel: "Rated {rating} out of 5",
    lovedBy: "Loved by {count} women across Indonesia",
    rating: "4.9",
    reviewCount: "12,000+",
    imageAlt: "A smiling woman enjoying a golden chocolate-peanut ropang with a cup of coffee",
    freshly: "Freshly toasted",
    baked: "Baked at 06:00 today",
    favorite: "Her favorite",
    favoriteName: "Dark Cocoa Peanut",
  },
  marquee: [
    "Slow-toasted daily",
    "No artificial colors",
    "Small-batch spreads",
    "Gift-ready boxes",
    "Made for busy women",
    "Ready in three minutes",
    "Delivered within 24 hours",
  ],
  social: {
    ariaLabel: "Community and results",
    stats: [
      { suffix: "K+", label: "Women ordering monthly" },
      { suffix: "/5", label: "Average rating" },
      { suffix: "%", label: "Say they'd reorder" },
      { suffix: " min", label: "From pantry to plate" },
    ],
    goalEyebrow: "Our road to 5.000.000 sales",
    goalTitle: { pre: "Every box brings us closer to ", em: "5.000.000", post: " sales." },
    goalBody: "Thank you for making ropang a ritual for women across Indonesia.",
    sold: "{n} sold",
    goalLabel: "Goal {n}",
    percent: "{p}% there",
    progressLabel: "Sales progress toward goal",
  },
  features: {
    eyebrow: "The Ropang difference",
    title: { pre: "Small details, ", em: "big", post: " indulgence." },
    description: "We obsess over the things you can taste and the things you never have to worry about.",
    items: [
      {
        title: "Slow-toasted, never rushed",
        text: "Each slice is toasted low and slow until the edges turn golden and the center stays tender.",
      },
      {
        title: "Clean, recognizable ingredients",
        text: "Real butter, roasted nuts and fruit-forward spreads. No artificial colors, ever.",
      },
      {
        title: "Ready in three minutes",
        text: "Toast, spread, savor. The easiest little ritual between meetings and school runs.",
      },
      {
        title: "Portion-smart minis",
        text: "Bite-size slices, six per box. Indulge beautifully without overdoing it.",
      },
      {
        title: "Gift-ready, every time",
        text: "Ribboned boxes and a handwritten note option, made for birthdays, thank-yous and treat-yourself days.",
      },
      {
        title: "Delivered fresh within 24 hours",
        text: "Packed cool and dispatched the morning we bake, so every crunch arrives right.",
      },
    ],
  },
  flavors: {
    eyebrow: "Our flavors",
    title: { pre: "Pick your ", em: "ritual.", post: "" },
    description:
      "Four signature flavors, each slow-toasted and finished by hand. Find the one that feels like you today.",
    groupLabel: "Choose a flavor",
    perBox: "per box · 6 mini slices",
    sixSlices: "6 mini slices",
    ready: "Ready in three minutes",
    addToBag: "Add to bag · {price}",
    added: "Added to your bag",
    decrease: "Decrease quantity",
    increase: "Increase quantity",
    perks: ["Free delivery over Rp 150.000", "Dispatched within 24 hours", "Freshness guarantee"],
    imageAlt: "Ropang Yummy {name} box with golden toasted slices",
    items: {
      cocoa: {
        name: "Dark Cocoa Peanut",
        short: "Dark Cocoa",
        badge: "Best seller",
        notes: ["70% dark cocoa", "Roasted peanut", "Sea salt"],
        description:
          "Velvety dark cocoa folded into roasted peanut butter, finished with a whisper of sea salt. Our most-loved ritual, and for good reason.",
      },
      strawberry: {
        name: "Strawberry Cream",
        short: "Strawberry",
        badge: "Fan favorite",
        notes: ["Freeze-dried strawberry", "Vanilla bean cream", "Honey drizzle"],
        description:
          "Bright, freeze-dried strawberry over vanilla bean cream. Light, rosy and playful, the treat your inner girl has been waiting for.",
      },
      matcha: {
        name: "Matcha Honey",
        short: "Matcha",
        badge: "New",
        notes: ["Ceremonial matcha", "Wildflower honey", "Toasted sesame"],
        description:
          "Grassy ceremonial-grade matcha with floral wildflower honey and nutty sesame. Calm, elegant and beautifully balanced.",
      },
      garlic: {
        name: "Golden Garlic Herb",
        short: "Savory",
        badge: "Savory pick",
        notes: ["Cultured butter", "Roasted garlic", "Fresh parsley"],
        description:
          "Cultured butter, slow-roasted garlic and fresh parsley on a golden crust. A savory pause for brunch, boardroom snacks or a glass of wine.",
      },
    },
  },
  benefits: {
    eyebrow: "Why women choose us",
    title: { pre: "Indulgence designed around ", em: "your", post: " real life." },
    quote: "“My 3pm ritual, sorted.”",
    quoteBy: "Sari, Jakarta · Ritual subscriber",
    cta: "Start your ritual",
    imageAlt: "A smiling woman enjoying a toasted ropang snack at a sunlit cafe",
    items: [
      {
        title: "Permission to indulge",
        text: "A treat that fits your life instead of fighting it. Real flavor, mini portions, zero guilt-trip.",
      },
      {
        title: "Ten minutes of calm",
        text: "A sensory pause: warm bread, the first crunch, a cup of tea. Your reset button, on demand.",
      },
      {
        title: "Mornings made easier",
        text: "Breakfast already decided. Pack a slice for the commute, share one with the kids, save the rest for later.",
      },
      {
        title: "Shared with the people you love",
        text: "Sisters' nights, office gifts, a surprise for Mom. Ropang is the easiest way to say you thought of them.",
      },
    ],
  },
  reviews: {
    eyebrow: "Real women, real rituals",
    title: { pre: "Loved in kitchens, offices and ", em: "everywhere between.", post: "" },
    rating: "4.9 / 5",
    verified: "12,000+ verified reviews",
    prev: "Previous reviews",
    next: "Next reviews",
    region: "Customer reviews, scroll horizontally",
    verifiedBadge: "Verified",
    stars: "{n} out of 5 stars",
    list: [
      {
        name: "Sari Wulandari",
        role: "Marketing lead",
        city: "Jakarta",
        quote: "My 3pm ritual now. The Dark Cocoa Peanut is dangerously good, and somehow I feel good about it too.",
      },
      {
        name: "Dewi Anggraini",
        role: "Mother of two",
        city: "Bandung",
        quote: "Ordered a box for my sisters' birthday and everyone asked where I got it. The packaging is gorgeous.",
      },
      {
        name: "Rina Kusuma",
        role: "Architect",
        city: "Surabaya",
        quote: "The matcha honey is a little luxury I refuse to give up. Floral, gentle and never cloying.",
      },
      {
        name: "Anindya Putri",
        role: "Freelance designer",
        city: "Yogyakarta",
        quote: "Crisp edges, soft middle, and it makes my slow mornings feel intentional. I subscribed on a whim.",
      },
      {
        name: "Maya Lestari",
        role: "Nurse",
        city: "Medan",
        quote: "After twelve-hour shifts, this is the treat I actually look forward to. Small things matter.",
      },
      {
        name: "Nadia Prameswari",
        role: "University student",
        city: "Bali",
        quote: "The kids fight over the strawberry cream. I have started hiding the last pieces, honestly.",
      },
    ],
  },
  pricing: {
    eyebrow: "Pricing",
    title: { pre: "Little luxuries, ", em: "priced", post: " for real life." },
    description: "No hidden fees and no lock-ins. Pause or cancel your ritual anytime.",
    billing: "Billing option",
    oneTime: "One-time",
    subscribe: "Subscribe",
    off: "−15%",
    save: "Save 15%",
    footnote: "Prices in IDR, including VAT. Subscription savings apply to every delivery.",
    plans: {
      taste: {
        name: "Taste Test",
        description: "Discover every flavor before you commit to a favorite.",
        cta: "Try the sampler",
        features: [
          "4 mini boxes, one of each flavor",
          "Gift-ready packaging",
          "Free delivery over Rp 150.000",
          "Full refund if it isn't your thing",
        ],
      },
      ritual: {
        name: "Ritual",
        description: "Your monthly moment of joy, delivered quietly to your door.",
        cadence: "/ month",
        badge: "Most loved",
        cta: "Start my ritual",
        features: [
          "3 boxes every month",
          "Choose or rotate flavors each cycle",
          "Free delivery, always",
          "Pause, skip or cancel in two taps",
          "A limited surprise flavor in your birthday month",
        ],
      },
      sisterhood: {
        name: "Sisterhood",
        description: "Made for sharing, gifting and spoiling the women who matter.",
        cta: "Gift the sisterhood",
        features: [
          "6 boxes to share",
          "Ribbon gift wrap included",
          "Handwritten card with your message",
          "Priority same-day dispatch",
        ],
      },
    },
  },
  faq: {
    eyebrow: "FAQ",
    title: { pre: "Questions, ", em: "answered.", post: "" },
    description: "Everything you need to know before your first bite.",
    stillCurious: "Still curious?",
    stillCuriousText: "Our team replies on WhatsApp within the hour, 8am to 9pm.",
    items: [
      {
        q: "What exactly is ropang?",
        a: "Ropang (roti panggang) is Indonesia's beloved toasted bread snack. We elevate it with slow toasting, real butter and small-batch spreads for a crisper, more indulgent bite.",
      },
      {
        q: "How long do they stay crisp?",
        a: "Best enjoyed within two days at room temperature. Re-crisp in a dry pan for 30 seconds to bring back that golden crunch.",
      },
      {
        q: "Can I pause or cancel my Ritual subscription?",
        a: "Yes. Pause, skip a month or cancel from your account in two taps. No phone calls, no pressure.",
      },
      {
        q: "Do you deliver outside Jakarta?",
        a: "We ship across Indonesia, with same-day dispatch in Jabodetabek and next-day delivery to most major cities. Delivery is free on orders over Rp 150.000.",
      },
      {
        q: "Are your ingredients artificial-free?",
        a: "We use no artificial colors and keep ingredient lists short and recognizable. Full ingredient and allergen information is printed on every box.",
      },
      {
        q: "Can I send a box as a gift?",
        a: "Absolutely. Choose Sisterhood gift wrap at checkout and add a handwritten note of up to 120 characters.",
      },
    ],
  },
  cta: {
    badge: "Welcome offer · 20% off your first box",
    title: { pre: "Your next favorite ritual starts with ", em: "one box.", post: "" },
    body: "Join 12,000+ women who have made a little deliciousness part of every day. Enter your email and we will send your code.",
    timerLabel: "Offer ends in",
    units: { days: "Days", hours: "Hours", min: "Min", sec: "Sec" },
    emailLabel: "Email address",
    placeholder: "you@email.com",
    submit: "Claim my 20% off",
    successBefore: "You are in! Check your inbox for code",
    successAfter: ".",
    code: "SISTER20",
    errorEmail: "Please enter a valid email address.",
    noSpam: "No spam, ever. Unsubscribe in one click.",
  },
  footer: {
    blurb:
      "Slow-toasted ropang layered with indulgent spreads. Made for the women who deserve something delicious, every day.",
    socials: ["Instagram", "TikTok", "WhatsApp"],
    backToTop: "Ropang Yummy, back to top",
    columns: [
      {
        title: "Shop",
        links: [
          { label: "Flavors", href: "#flavors" },
          { label: "Ritual subscription", href: "#pricing" },
          { label: "Gift boxes", href: "#pricing" },
          { label: "Reviews", href: "#reviews" },
        ],
      },
      {
        title: "Help",
        links: [
          { label: "FAQ", href: "#faq" },
          { label: "Shipping", href: "#faq" },
          { label: "Returns", href: "#faq" },
          { label: "Contact us", href: "#faq" },
        ],
      },
      {
        title: "Company",
        links: [
          { label: "Our story", href: "#benefits" },
          { label: "Careers", href: "#top" },
          { label: "Press kit", href: "#top" },
          { label: "Partners", href: "#top" },
        ],
      },
    ],
    copyright: "© 2026 Ropang Yummy. All rights reserved.",
    credits: "Crafted with care · Prices in IDR, including VAT",
  },
  sticky: { addToBag: "Add to bag" },
};

const id: Copy = {
  meta: {
    title: "Ropang Yummy | Roti Panggang yang Bikin Hati Senang",
    description:
      "Ropang Yummy: roti panggang renyah dengan selai melimpah, harga ramah di kantong, dibuat untuk kamu yang layak dapat camilan enak tiap hari.",
    htmlLang: "id",
  },
  ui: {
    skip: "Lewati ke konten",
    home: "Ropang Yummy, kembali ke atas",
    openMenu: "Buka menu",
    closeMenu: "Tutup menu",
    bagLabel: "Keranjang belanja, {count} item",
    mainNav: "Navigasi utama",
    shopNow: "Belanja sekarang",
    languageGroup: "Bahasa",
    toast: "{qty} × {label} sudah masuk keranjang",
  },
  nav: {
    links: [
      { label: "Varian", href: "#flavors" },
      { label: "Kenapa Ropang", href: "#benefits" },
      { label: "Ulasan", href: "#reviews" },
      { label: "Harga", href: "#pricing" },
      { label: "FAQ", href: "#faq" },
    ],
  },
  hero: {
    badge: "Baru! · Dipanggang pelan-pelan",
    titleLead: "Roti panggang",
    titleLine2: "yang bikin",
    accent: "hati senang.",
    description:
      "Ropang Yummy: roti panggang renyah, selai melimpah, harga ramah di kantong. Cemilan 3 menit buat kamu yang sibuk tapi tetap pengen dimanjain.",
    primaryCta: "Coba box pertama",
    secondaryCta: "Kenapa Ropang?",
    startingPrice: "Mulai Rp 59.000",
    freeDelivery: "Gratis ongkir min. belanja Rp 150.000",
    ratedLabel: "Rating {rating} dari 5",
    lovedBy: "Disukai {count} wanita di seluruh Indonesia",
    rating: "4.9",
    reviewCount: "12.000+",
    imageAlt: "Perempuan tersenyum menikmati ropang cokelat kacang dengan secangkir kopi",
    freshly: "Baru dipanggang",
    baked: "Dipanggang jam 06.00 pagi ini",
    favorite: "Favorit kamu",
    favoriteName: "Dark Cocoa Peanut",
  },
  marquee: [
    "Dipanggang pelan tiap hari",
    "Tanpa pewarna buatan",
    "Selai racikan kecil-kecilan",
    "Siap jadi kado",
    "Dibuat untuk perempuan sibuk",
    "Siap dalam tiga menit",
    "Dikirim dalam 24 jam",
  ],
  social: {
    ariaLabel: "Komunitas dan hasil",
    stats: [
      { suffix: "rb+", label: "Wanita yang pesan tiap bulan" },
      { suffix: "/5", label: "Rata-rata rating" },
      { suffix: "%", label: "Bilang mau beli lagi" },
      { suffix: " menit", label: "Dari lemari ke piring" },
    ],
    goalEyebrow: "Target kami 5.000.000 penjualan",
    goalTitle: { pre: "Setiap box bikin kami makin dekat ke ", em: "5.000.000", post: " penjualan." },
    goalBody: "Makasih sudah jadiin ropang kebiasaan manis perempuan di seluruh Indonesia.",
    sold: "{n} terjual",
    goalLabel: "Target {n}",
    percent: "{p}% tercapai",
    progressLabel: "Progres penjualan menuju target",
  },
  features: {
    eyebrow: "Kenapa Ropang?",
    title: { pre: "Detail kecil, ", em: "enaknya", post: " bikin ketagihan." },
    description: "Kami serius di hal yang bisa kamu rasakan, jadi kamu nggak perlu pusing soal yang lain.",
    items: [
      {
        title: "Dipanggang pelan, nggak buru-buru",
        text: "Setiap irisan dipanggang pelan sampai pinggirnya keemasan dan bagian dalamnya tetap lembut.",
      },
      {
        title: "Bahan jelas, nggak aneh-aneh",
        text: "Pakai mentega asli, kacang panggang, dan selai buah. Tanpa pewarna buatan.",
      },
      {
        title: "Siap dalam tiga menit",
        text: "Oles, panggang, nikmati. Camilan paling praktis di sela meeting dan antar jemput anak.",
      },
      {
        title: "Porsi mungil, puas di hati",
        text: "Potongan kecil, enam per box. Bisa ngemil tanpa bikin perut dan dompet kebanyakan.",
      },
      {
        title: "Siap jadi kado",
        text: "Kemasan pita dan kartu tulisan tangan, cocok buat ulang tahun atau sekadar bilang makasih.",
      },
      {
        title: "Dikirim segar dalam 24 jam",
        text: "Dikemas dingin dan dikirim pagi setelah dipanggang, jadi tetap renyah sampai di rumah.",
      },
    ],
  },
  flavors: {
    eyebrow: "Varian kami",
    title: { pre: "Pilih ", em: "favoritmu.", post: "" },
    description:
      "Empat varian andalan, dipanggang pelan dan dikerjakan dengan tangan. Cari yang paling pas buat mood kamu hari ini.",
    groupLabel: "Pilih rasamu",
    perBox: "per box · 6 potong mini",
    sixSlices: "6 potong mini",
    ready: "Siap dalam tiga menit",
    addToBag: "Masukin keranjang · {price}",
    added: "Sudah masuk keranjang",
    decrease: "Kurangi jumlah",
    increase: "Tambah jumlah",
    perks: ["Gratis ongkir min. belanja Rp 150.000", "Dikirim dalam 24 jam", "Garansi kesegaran"],
    imageAlt: "Box Ropang Yummy {name} dengan irisan keemasan",
    items: {
      cocoa: {
        name: "Dark Cocoa Peanut",
        short: "Dark Cocoa",
        badge: "Paling laris",
        notes: ["Cokelat hitam 70%", "Kacang panggang", "Garam laut"],
        description:
          "Cokelat hitam yang lembut dipadu selai kacang panggang, ditutup sedikit garam laut. Favorit banyak orang, dan wajar banget.",
      },
      strawberry: {
        name: "Strawberry Cream",
        short: "Stroberi",
        badge: "Favorit fans",
        notes: ["Stroberi freeze-dried", "Krim vanila", "Sentuhan madu"],
        description:
          "Stroberi freeze-dried yang segar di atas krim vanila. Ringan, manis, dan bikin mood langsung naik.",
      },
      matcha: {
        name: "Matcha Honey",
        short: "Matcha",
        badge: "Baru",
        notes: ["Matcha premium", "Madu bunga liar", "Wijen panggang"],
        description:
          "Matcha khas dengan madu bunga liar dan wijen sangrai. Tenang, elegan, dan pas di lidah.",
      },
      garlic: {
        name: "Golden Garlic Herb",
        short: "Gurih",
        badge: "Pilihan gurih",
        notes: ["Mentega kultur", "Bawang putih panggang", "Peterseli segar"],
        description:
          "Mentega kultur, bawang putih panggang, dan peterseli segar di atas kulit keemasan. Pas buat sarapan atau ngemil santai.",
      },
    },
  },
  benefits: {
    eyebrow: "Kenapa perempuan pilih kami",
    title: { pre: "Manjain diri yang ", em: "tetap hemat", post: ", pas buat hidup kamu." },
    quote: "“Ritual jam 3 sore, beres.”",
    quoteBy: "Sari, Jakarta · Pelanggan Ritual",
    cta: "Mulai ritual kamu",
    imageAlt: "Perempuan tersenyum menikmati camilan ropang panggang di kafe yang cerah",
    items: [
      {
        title: "Boleh manjain diri",
        text: "Camilan yang pas di kantong dan nggak bikin rasa bersalah. Rasa mantap, porsi mungil, hati tenang.",
      },
      {
        title: "Sepuluh menit buat tenang",
        text: "Hangatnya roti, renyah gigitan pertama, teh di tangan. Tombol reset kecil kapan pun kamu butuh.",
      },
      {
        title: "Pagi jadi lebih ringan",
        text: "Sarapan sudah beres. Bawa sepotong buat di jalan, bagi ke anak, sisanya simpan buat nanti.",
      },
      {
        title: "Bisa dibagi ke orang tersayang",
        text: "Arisan sisters, kado kantor, atau kejutan buat Ibu. Ropang jadi cara paling gampang bilang kamu kepikiran mereka.",
      },
    ],
  },
  reviews: {
    eyebrow: "Cerita perempuan sungguhan",
    title: { pre: "Disukai di dapur, kantor, dan ", em: "di sela-sela kesibukan.", post: "" },
    rating: "4.9 / 5",
    verified: "12.000+ ulasan terverifikasi",
    prev: "Ulasan sebelumnya",
    next: "Ulasan berikutnya",
    region: "Ulasan pelanggan, geser ke samping",
    verifiedBadge: "Terverifikasi",
    stars: "{n} dari 5 bintang",
    list: [
      {
        name: "Sari Wulandari",
        role: "Marketing",
        city: "Jakarta",
        quote:
          "Ritual jam 3 sore aku sekarang. Dark Cocoa Peanut-nya bikin nagih, dan anehnya tetap nggak bikin nyesel.",
      },
      {
        name: "Dewi Anggraini",
        role: "Ibu dua anak",
        city: "Bandung",
        quote:
          "Pesan satu box buat ulang tahun adik-adikku, semua nanya beli di mana. Kemasannya cantik, harganya masih masuk akal.",
      },
      {
        name: "Rina Kusuma",
        role: "Arsitek",
        city: "Surabaya",
        quote: "Matcha honey itu kemewahan kecil yang nggak mau aku lepas. Lembut, floral, dan nggak eneg.",
      },
      {
        name: "Anindya Putri",
        role: "Desainer lepas",
        city: "Yogyakarta",
        quote:
          "Pinggirnya renyah, tengahnya lembut. Pagi yang pelan jadi terasa lebih berarti. Awalnya iseng langganan, sekarang nggak mau berhenti.",
      },
      {
        name: "Maya Lestari",
        role: "Perawat",
        city: "Medan",
        quote: "Setelah shift dua belas jam, ini camilan yang bener-bener aku tunggu. Hal kecil itu penting.",
      },
      {
        name: "Nadia Prameswari",
        role: "Mahasiswi",
        city: "Bali",
        quote: "Anak-anak rebutan Strawberry Cream. Akhirnya aku sembunyiin potongan terakhir, jujur.",
      },
    ],
  },
  pricing: {
    eyebrow: "Harga",
    title: { pre: "Manjain diri, ", em: "harga", post: " yang ramah di kantong." },
    description: "Tanpa biaya tersembunyi, tanpa kontrak. Bisa jeda atau berhenti kapan saja.",
    billing: "Pilihan pembayaran",
    oneTime: "Sekali beli",
    subscribe: "Langganan",
    off: "−15%",
    save: "Hemat 15%",
    footnote: "Harga dalam Rupiah, sudah termasuk PPN. Hemat langganan berlaku di setiap pengiriman.",
    plans: {
      taste: {
        name: "Taste Test",
        description: "Coba semua rasa dulu sebelum pilih satu favorit.",
        cta: "Coba paket sampler",
        features: [
          "4 box mini, satu dari tiap rasa",
          "Kemasan siap kado",
          "Gratis ongkir min. belanja Rp 150.000",
          "Uang kembali kalau nggak cocok",
        ],
      },
      ritual: {
        name: "Ritual",
        description: "Momen manis bulanan, datang diam-diam ke depan pintumu.",
        cadence: "/ bulan",
        badge: "Paling disukai",
        cta: "Mulai ritual saya",
        features: [
          "3 box setiap bulan",
          "Pilih atau gilir rasa tiap periode",
          "Gratis ongkir selamanya",
          "Jeda, lewati, atau berhenti dalam dua ketukan",
          "Rasa kejutan terbatas di bulan ulang tahunmu",
        ],
      },
      sisterhood: {
        name: "Sisterhood",
        description: "Buat dibagi, dikado, dan memanjakan perempuan tersayang.",
        cta: "Kado untuk sisterhood",
        features: [
          "6 box untuk dibagi",
          "Bungkus kado pita sudah termasuk",
          "Kartu tulisan tangan dengan pesanmu",
          "Pengiriman prioritas di hari yang sama",
        ],
      },
    },
  },
  faq: {
    eyebrow: "Tanya jawab",
    title: { pre: "Ada pertanyaan? ", em: "Kami jawab.", post: "" },
    description: "Semua yang perlu kamu tahu sebelum gigitan pertama.",
    stillCurious: "Masih penasaran?",
    stillCuriousText: "Tim kami balas lewat WhatsApp dalam sejam, jam 08.00 sampai 21.00.",
    items: [
      {
        q: "Ropang itu apa sih?",
        a: "Ropang (roti panggang) adalah camilan roti panggang favorit orang Indonesia. Kami panggang pelan, pakai mentega asli, dan selai racikan kecil-kecilan supaya lebih renyah dan nikmat.",
      },
      {
        q: "Berapa lama masih renyah?",
        a: "Paling enak dihabiskan dalam dua hari di suhu ruang. Panaskan sebentar di wajan kering 30 detik supaya kembali renyah.",
      },
      {
        q: "Langganan Ritual bisa dijeda atau dibatalkan?",
        a: "Bisa. Jeda, lewati satu bulan, atau batalkan dari akunmu dalam dua ketukan. Tanpa telepon, tanpa maksa.",
      },
      {
        q: "Kirim ke luar Jakarta bisa?",
        a: "Bisa, kami kirim ke seluruh Indonesia. Dikirim di hari yang sama untuk Jabodetabek dan besoknya ke sebagian besar kota besar. Gratis ongkir untuk belanja di atas Rp 150.000.",
      },
      {
        q: "Bahannya aman tanpa bahan buatan?",
        a: "Kami tidak pakai pewarna buatan dan menjaga daftar bahan tetap singkat dan jelas. Daftar bahan dan alergen lengkap tercetak di setiap box.",
      },
      {
        q: "Bisa kirim sebagai kado?",
        a: "Bisa banget. Pilih kemasan kado Sisterhood saat checkout dan tambahkan kartu tulisan tangan hingga 120 karakter.",
      },
    ],
  },
  cta: {
    badge: "Promo sambutan · diskon 20% box pertama",
    title: { pre: "Ritual favoritmu dimulai dari ", em: "satu box saja.", post: "" },
    body: "Gabung bersama 12.000+ perempuan yang sudah menjadikan camilan enak bagian dari keseharian. Masukkan email, kode diskonnya kami kirim.",
    timerLabel: "Promo berakhir dalam",
    units: { days: "Hari", hours: "Jam", min: "Menit", sec: "Detik" },
    emailLabel: "Alamat email",
    placeholder: "kamu@email.com",
    submit: "Klaim diskon 20%",
    successBefore: "Berhasil! Cek inbox kamu untuk kode",
    successAfter: ".",
    code: "SISTER20",
    errorEmail: "Masukkan alamat email yang valid ya.",
    noSpam: "Tanpa spam. Berhenti langganan kapan saja.",
  },
  footer: {
    blurb:
      "Roti panggang renyah dengan selai melimpah. Dibuat untuk kamu yang layak dapat camilan enak tiap hari, tanpa bikin dompet kering.",
    socials: ["Instagram", "TikTok", "WhatsApp"],
    backToTop: "Ropang Yummy, kembali ke atas",
    columns: [
      {
        title: "Belanja",
        links: [
          { label: "Varian", href: "#flavors" },
          { label: "Langganan Ritual", href: "#pricing" },
          { label: "Kado", href: "#pricing" },
          { label: "Ulasan", href: "#reviews" },
        ],
      },
      {
        title: "Bantuan",
        links: [
          { label: "FAQ", href: "#faq" },
          { label: "Pengiriman", href: "#faq" },
          { label: "Pengembalian", href: "#faq" },
          { label: "Hubungi kami", href: "#faq" },
        ],
      },
      {
        title: "Perusahaan",
        links: [
          { label: "Cerita kami", href: "#benefits" },
          { label: "Karier", href: "#top" },
          { label: "Press kit", href: "#top" },
          { label: "Mitra", href: "#top" },
        ],
      },
    ],
    copyright: "© 2026 Ropang Yummy. Hak cipta dilindungi.",
    credits: "Dibuat dengan sepenuh hati · Harga dalam Rupiah, sudah termasuk PPN",
  },
  sticky: { addToBag: "Masukin keranjang" },
};

export const copy: Record<Lang, Copy> = { en, id };

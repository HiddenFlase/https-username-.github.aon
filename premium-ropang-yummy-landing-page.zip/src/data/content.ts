import type { FlavorId, PlanId } from "@/i18n/copy";

/** Language-independent data: prices, colors and metrics. Text lives in src/i18n/copy.ts. */

/** Price of one signature box (6 mini slices), in IDR. */
export const BOX_PRICE = 59000;

/**
 * Placeholder metrics: replace with your real numbers before launch.
 * Labels and suffixes are translated in src/i18n/copy.ts.
 */
export const statNumbers = [
  { to: 12, decimals: 0 },
  { to: 4.9, decimals: 1 },
  { to: 92, decimals: 0 },
  { to: 3, decimals: 0 },
];

/** Sales goal progress shown in the social proof section. */
export const goal = {
  current: 3250000,
  target: 5000000,
};

export const flavors: { id: FlavorId; color: string }[] = [
  { id: "cocoa", color: "#7a4a3a" },
  { id: "strawberry", color: "#e0637f" },
  { id: "matcha", color: "#7d9b6a" },
  { id: "garlic", color: "#d9a441" },
];

export const planPrices: Record<PlanId, { price: number; subscribePrice?: number }> = {
  taste: { price: 89000, subscribePrice: 75700 },
  ritual: { price: 143700 },
  sisterhood: { price: 289000, subscribePrice: 245700 },
};

export const planOrder: PlanId[] = ["taste", "ritual", "sisterhood"];
